var express = require('express');
const User = require('./model/user');
var router = express.Router();

/* Delete user listing. */
router.delete('/', authenticatetoken, function (req, res) {

  console.log("Inside delete user service: " + req.query.email)

  let deleteUser = function () {
    return new Promise((resolve, reject) => {
      User.deleteOne({
        email: req.query.email
      }).then(data => {
        console.log("Delete user Response from MongoDB: " + data)
        res.json(data)
        resolve(data)
      }).catch(err => {
        console.log("Error occurred while deleting user: " + err)
        resolve(null)
      })
    });
  }

  start()

  function start() {
    deleteUser();
  }
});



module.exports = router;