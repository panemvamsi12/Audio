var express = require('express');
var router = express.Router();

/* Update user listing. */
router.put('/', authenticatetoken, function (req, res) {

  console.log("Inside update user service: " + JSON.stringify(req.body))

  let updateUser = function () {
    return new Promise((resolve, reject) => {
      User.updateOne({
        name: req.body.name,
        image: req.body.image,
        Desc: req.body.Desc,
        song: req.body.song,
      }).then(data => {
        console.log("Update user Response from MongoDB: " + data)
        res.json(data)
        resolve(data)
      }).catch(err => {
        console.log("Error occurred while updating user: " + err)
        resolve(null)
      })
    });
  }

  start()

  function start() {
    updateUser();
  }
});



module.exports = router;