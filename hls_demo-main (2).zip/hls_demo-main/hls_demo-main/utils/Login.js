var express = require('express');
var router = express.Router();

router.post('/', function (req, res) {
  var username = req.body.username;
  let findUser = function () {
    return new Promise((resolve, reject) => {
      User
        .findOne({ username: username })
        .then(data => {
          console.log("User data: " + data)
          if (data.password == req.body.password) {
            const user = { user: username }
            const token = jwt.sign({ user }, "app_secret_token");
            console.log("JSON Web Token: " + token);
            res.json({ "accessToken": token });
          } else {
            res.json({ "status": "FAIL" });
          }
          resolve(data)
        }).catch(err => {
          console.log("User not Found: " + err);
          resolve(null);
        })
    });
  }

  login()

  function login() {
    console.log("Inside login() function")
    findUser();
  }

});

module.exports = router;